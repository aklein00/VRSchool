VR High School — individual black-and-white character concepts
29 October 2026

13 faculty and 5 players. One full-body drawing per PNG on plain white paper.
Guided by Arthur Klein's original goblin and yeti drawings.
Generated with the built-in image generation tool.

Faculty: 01 English Beholder, 02 Math Yeti, 03 Science Chuul, 04 History Displacer Beast, 05 Geography Ettin, 06 Language Arts Brass Dragon, 07 Health Giant Spider, 08 PE Gnoll, 09 Art Oobleck, 10 Music Goblin, 11 Drama Medusa, 12 Technology Mimic, 13 Headmaster Lich.
Players: 14 Human Wizard, 15 Dwarf Fighter, 16 Elf Ranger, 17 Halfling Bard, 18 Tiefling Cleric.
