# VR School character line drawings

18 current individual drawings: 13 faculty and 5 players. Revised 2026-10-29: female Language Arts (she/her), female Physical Education (she/her), non-binary Art (they/them). Previous art is archived separately in the project.
