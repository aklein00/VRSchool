Goblin music teacher — GIMP texture sources

Ten native XCF documents, each with eight layers. Open in GIMP. Show the UV guide while locating a surface and hide it before exporting. Paint on Your paint edits, or adjust the base palette, shadows, washes, highlights, warm accents and brush strokes. Save XCF to retain layers. Export each visible composition as NN_Name_BaseColor.png to update the corresponding PNG in the Blender delivery textures folder. Saving XCF alone does not update Blender. The full delivery includes the Blender project, texture reload helper, UV guides, roughness PNGs and detailed instructions.

The textures are procedurally authored in a hand-painted style and are fully editable raster layers.
